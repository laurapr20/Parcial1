const productos = [
  {
    nombre: "Cold brew",
    descripcion: "Café frío, intenso y refrescante.",
  },
  {
    nombre: "Flat white",
    descripcion: "Doble shot de espresso con leche texturizada.",
  },
  {
    nombre: "Mocca caliente",
    descripcion: "Shot de espresso con cocoa y salsa de chocolate.",
  },
  {
    nombre: "Mocca frío",
    descripcion: "Shot de espresso con cocoa, salsa de chocolate y leche texturizada.",
  },
  {
    nombre: "Prensa francesa",
    descripcion: "Método de extracción con mayor densidad en la bebida.",
  },
  {
    nombre: "Frappé de café",
    descripcion: "Granizado a base de café con caramelo y crema chantilly.",
  },
];

function mostrarProductos() {
  const productosContainer = document.getElementById("productos-container");

  productos.forEach((producto, index) => {
    const productoDiv = document.createElement("div");
    productoDiv.classList.add("producto");

    productoDiv.innerHTML = `
      <h3>${producto.nombre}</h3>
      <p>${producto.descripcion}</p>
    `;

    productosContainer.appendChild(productoDiv);
  });
}

mostrarProductos();
