document.addEventListener("DOMContentLoaded", function () {
  
    const verMasButton = document.getElementById("ver-mas-button");
    const productosSection = document.getElementById("productos");
    const colaboradoresSection = document.getElementById("colaboradores");
    const modal = document.getElementById("modal");
    const aceptarButton = document.getElementById("aceptar-button");
    const cancelarButton = document.getElementById("cancelar-button");
  
 
    verMasButton.addEventListener("click", function () {
      modal.style.display = "block";
    });

    aceptarButton.addEventListener("click", function () {

      modal.style.display = "none";
 
      verMasButton.style.display = "none";
      

      const productosButton = document.querySelector("a[href='#productos']");
      const colaboradoresButton = document.querySelector("a[href='#colaboradores']");
      productosButton.style.display = "inline";
      colaboradoresButton.style.display = "inline";
      
  
      productosSection.style.display = "block";
      colaboradoresSection.style.display = "block";
    });

    cancelarButton.addEventListener("click", function () {
  
      modal.style.display = "none";
    });
  });
  